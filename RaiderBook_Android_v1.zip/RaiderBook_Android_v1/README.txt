Raider Book Android project.
Open the project folder in a compatible Android development environment and build a debug APK.
